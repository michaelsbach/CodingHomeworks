#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int countWords(FILE *infile){
    size_t count=0;
    char temp;
    
    while(1){
        temp = getc(infile);
        if (temp == EOF){
            break;
        }
        else if (temp == ' ' || temp == '\t' || temp == '\n'){
            count++;
        }
    }
    return count;
}

int main(int argc, char *argv[]){
    
    pid_t childPid, wpid;
    int i, numWords, status=0;
    FILE *input;
    char *fileName;

    for(i=1; i < argc; i++){
        if (childPid = fork() == 0){
            fileName = argv[i];
            if (access(fileName,F_OK) != -1){
                input = fopen(fileName, "r");
                numWords = countWords(input);
                fclose(input);
                printf("Child process for %s: number of words is %d\n", fileName, numWords);
            }
            else{
                printf("The file named %s does not exist!\n", fileName);
            }
            exit(0);
        }

    }


    while ((wpid = wait(&status)) > 0);

    if (wpid != 0){
        printf("All %d files have been counted!\n", argc-1);
    }

}
