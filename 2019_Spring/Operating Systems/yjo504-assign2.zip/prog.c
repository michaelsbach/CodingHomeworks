#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct PCB_st{
    int ProcId;
    int ProcPR;
    int CPUburst;
    int Reg[8];
    int queueEnterClock, waitingTime;
    struct PCB_st *next;
}PCB;
#define STUDENT_NAME "Michael Schwarzbach"
typedef int bool;
#define true 1
#define false 0
#define SJF 2
#define PR 3

int CPUreg[8] = {0};
PCB *Head = NULL;
PCB *Tail = NULL;

int CLOCK = 0;
int Total_waiting_time=0; 
int Total_turnaround_time=0; 
int Total_job=0;



void FIFO_Scheduling(){
    PCB *temp;
    int i;
    double avgWaitTime, avgTrnTime, thruput;
    while (Head != NULL){
        temp = Head;
        Head = Head->next;
        memcpy(CPUreg, temp->Reg, sizeof(temp->Reg));
        for(i=0; i<sizeof(CPUreg)/4; i++){
            CPUreg[i] += 1;
        }
        memcpy(temp->Reg, CPUreg, sizeof(CPUreg));
        
        temp->waitingTime += CLOCK - temp->queueEnterClock;
        Total_waiting_time += temp->waitingTime;
        CLOCK += temp->CPUburst;
        Total_turnaround_time += CLOCK;
        Total_job += 1;
        printf("Process %d is completed at %2d ms\n", temp->ProcId, CLOCK);
        free(temp);
    }
    avgWaitTime = ((double)Total_waiting_time)/Total_job;
    avgTrnTime = ((double)Total_turnaround_time)/Total_job;
    thruput = Total_job/((double)CLOCK);
    printf("\nAverage waiting time = %6.2f ms      (%d/%d)\nAverage Turnaround time = %6.2f ms   (%d/%d)\n", avgWaitTime,
            Total_waiting_time, Total_job, avgTrnTime, Total_turnaround_time, Total_job);
    printf("Throughput = %.2f jobs per ms         (%d/%d)\n\n",thruput, Total_job, CLOCK);
    return;
}

//overwrites copy PCB's data with the og PCB's data, keeping pointers intact.
void copyData(PCB *og, PCB *copy){
    copy->ProcId = og->ProcId;
    copy->ProcPR = og->ProcPR;
    copy->CPUburst = og->CPUburst;
    memcpy(copy->Reg, og->Reg, sizeof(og->Reg));
    copy->waitingTime = og->waitingTime;
    copy->queueEnterClock = og->queueEnterClock;
    return;
}

//calls copyData to swap 2 struct's data; utilizes temporary PCB struct to do so
void swapData(PCB *a, PCB *b){
    PCB *pSwap = (PCB*)malloc(sizeof(PCB)); 
    copyData(a, pSwap);
    copyData(b, a);
    copyData(pSwap, b);
    free(pSwap);
    return;
}

//sorts passed-in LL depending on algoType (for SJF, shortest jobs first. for PR, highest priority first.
void sortLL(int algoType, PCB *Head){
    bool swapFlag=true;
    int i;
    PCB *left = NULL;
    PCB *temp = NULL;
    if (Head == NULL)
        return;
    while(swapFlag == true){
        swapFlag = false;
        if(algoType == SJF){
            for(temp = Head; temp->next != left; temp = temp->next){
                if(temp->CPUburst > temp->next->CPUburst){
                    swapData(temp, temp->next);
                    swapFlag = true;
                }
            }
        }
        else if (algoType == PR){
            for(temp = Head; temp->next != left; temp = temp->next){
                if(temp->ProcPR < temp->next->ProcPR){
                    swapData(temp->next, temp);
                    swapFlag = true;
                }
            }
        }
        left = temp;
    }

}

void SJF_Scheduling(){
    PCB *temp;
    int i;
    double avgWaitTime, avgTrnTime, thruput;
    sortLL(SJF, Head); 
    while (Head != NULL){
        temp = Head;
        Head = Head->next;
        memcpy(CPUreg, temp->Reg, sizeof(temp->Reg));
        for(i=0; i<sizeof(CPUreg)/4; i++){
            CPUreg[i] += 1;
        }
        memcpy(temp->Reg, CPUreg, sizeof(CPUreg));
        
        temp->waitingTime += CLOCK - temp->queueEnterClock;
        Total_waiting_time += temp->waitingTime;
        CLOCK += temp->CPUburst;
        Total_turnaround_time += CLOCK;
        Total_job += 1;
        printf("Process %d is completed at %2d ms\n", temp->ProcId, CLOCK);
        free(temp);
    }
    avgWaitTime = ((double)Total_waiting_time)/Total_job;
    avgTrnTime = ((double)Total_turnaround_time)/Total_job;
    thruput = Total_job/((double)CLOCK);
    printf("\nAverage waiting time = %6.2f ms      (%d/%d)\nAverage Turnaround time = %6.2f ms   (%d/%d)\n", avgWaitTime,
            Total_waiting_time, Total_job, avgTrnTime, Total_turnaround_time, Total_job);
    printf("Throughput = %.2f jobs per ms         (%d/%d)\n\n",thruput, Total_job, CLOCK);
    return;

}
void PR_Scheduling(){
    PCB *temp;
    int i;
    double avgWaitTime, avgTrnTime, thruput;
    sortLL(PR, Head); 
    while (Head != NULL){
        temp = Head;
        Head = Head->next;
        memcpy(CPUreg, temp->Reg, sizeof(temp->Reg));
        for(i=0; i<sizeof(CPUreg)/4; i++){
            CPUreg[i] += 1;
        }
        memcpy(temp->Reg, CPUreg, sizeof(CPUreg));
        
        temp->waitingTime += CLOCK - temp->queueEnterClock;
        Total_waiting_time += temp->waitingTime;
        CLOCK += temp->CPUburst;
        Total_turnaround_time += CLOCK;
        Total_job += 1;
        printf("Process %d is completed at %2d ms\n", temp->ProcId, CLOCK);
        free(temp);
    }
    avgWaitTime = ((double)Total_waiting_time)/Total_job;
    avgTrnTime = ((double)Total_turnaround_time)/Total_job;
    thruput = Total_job/((double)CLOCK);
    printf("\nAverage waiting time = %6.2f ms      (%d/%d)\nAverage Turnaround time = %6.2f ms   (%d/%d)\n", avgWaitTime,
            Total_waiting_time, Total_job, avgTrnTime, Total_turnaround_time, Total_job);
    printf("Throughput = %.2f jobs per ms         (%d/%d)\n\n",thruput, Total_job, CLOCK);
    return;
}


void RR_Scheduling(int quantum){
    PCB *temp = NULL;
    int i;
    double avgWaitTime, avgTrnTime, thruput;
    while (Head != NULL){
        temp = Head;
        //if only 1 element left in LL, do not access null memory
        if (!(temp == Head && temp == Tail)){
            Head = Head->next;
        }
        memcpy(CPUreg, temp->Reg, sizeof(temp->Reg));
        for(i=0; i<sizeof(CPUreg)/4; i++){
            CPUreg[i] += 1;
        }
        memcpy(temp->Reg, CPUreg, sizeof(CPUreg));
        if (temp->CPUburst <= quantum){ 
            temp->waitingTime += CLOCK - temp->queueEnterClock;
            Total_waiting_time += temp->waitingTime;
            CLOCK += temp->CPUburst;
            Total_turnaround_time += CLOCK;
            Total_job += 1;
            printf("Process %d is completed at %2d ms\n", temp->ProcId, CLOCK);
            //if about to free last element, ensures a double free will not happen 
            if (temp == Head && temp == Tail){
                Head = NULL;
                Tail = NULL;
            }
            free(temp);
        }
        
        else{
            temp->waitingTime += CLOCK - temp->queueEnterClock;
            CLOCK += quantum;
            temp->CPUburst -= quantum;
            temp->queueEnterClock = CLOCK;
            Tail->next = temp;
            Tail = temp;
        }
    }
    
    avgWaitTime = ((double)Total_waiting_time)/Total_job;
    avgTrnTime = ((double)Total_turnaround_time)/Total_job;
    thruput = Total_job/((double)CLOCK);
    printf("\nAverage waiting time = %6.2f ms      (%d/%d)\nAverage Turnaround time = %6.2f ms   (%d/%d)\n", avgWaitTime,
            Total_waiting_time, Total_job, avgTrnTime, Total_turnaround_time, Total_job);
    printf("Throughput = %.2f jobs per ms         (%d/%d)\n\n",thruput, Total_job, CLOCK);
    
    return;
    

}
int main(int argc, char *argv[]){
    FILE *input;
    int pid, pp, cpuBurst;
    int quant;
    PCB *temp = NULL;
    char algo = argv[2][0];
    //open input file (different argv location if quantum included or not)
    if (algo == 'R'){
        input = fopen(argv[6], "r");
        quant = atoi(argv[4]);
        printf("\nStudent Name: %s\nInput File Name : %s\nCPU Scheduling Alg : %s\n\n", 
                STUDENT_NAME, argv[6], argv[2]);
    }
    else{
        input = fopen(argv[4], "r");
        printf("\nStudent Name: %s\nInput File Name : %s\nCPU Scheduling Alg : %s\n\n", 
                STUDENT_NAME, argv[4], argv[2]);
    }
    //for each line:
    while (fscanf(input, "%d %d %d", &pid, &pp, &cpuBurst) == 3){
        if( Head == NULL){
            Head =(PCB*)malloc(sizeof(PCB));
            Head->ProcId = pid;
            Head->ProcPR = pp;
            Head->CPUburst = cpuBurst;
            Head->Reg[8] = pid;
            Head->queueEnterClock = Head->waitingTime = 0;
            Tail = Head;
        }
        else if(temp == NULL){
            temp = (PCB*)malloc(sizeof(PCB));            
            temp->ProcId = pid;
            temp->ProcPR = pp;
            temp->CPUburst = cpuBurst;
            temp->Reg[8] = pid;
            temp->queueEnterClock = Head->waitingTime = 0;
            temp->next = NULL;
            Tail->next = temp;
            Tail = temp;
            temp = NULL;
        }
    }
    //close input file
    fclose(input);
    //Print your name, the name of scheduling algorithm, and the input file name,
    switch (algo){
        case 'F':
            FIFO_Scheduling();
            break;
        case 'S':
            SJF_Scheduling();   
            break;
        case 'P':
            PR_Scheduling();
            break;
        case 'R':
            RR_Scheduling(quant);
            break;
        default:
            fprintf(stderr, "ERROR: No proper scheduling algorithm found. Please try running the program again.\n");
            exit(1);
        
    }

}
