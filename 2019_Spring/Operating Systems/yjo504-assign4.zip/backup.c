#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
typedef struct sortData{
    int size;
    double *array;
}doubleArray;

typedef struct arrays{
    double *half_1;
    double *half_2;
    int n;
}arrs;


static double *unsorted;
static double *sorted;
static double *unsorted_copy;

void sortDoubleArray(doubleArray *info){
    double *array = info->array;
    int size = info->size;
    int i = 0;
    int j = 0;
    double temp = 0;
    for (i = 0; i<size-1; i++){
        for (j = 0; j<size-1-i; j++){
            if (array[j] > array[j+1]){
                temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
}

void *sortThread(void* arg){
    doubleArray *ptr;
    ptr = (doubleArray*)arg;
    sortDoubleArray(ptr);
    pthread_exit(NULL);
}

void *mergeThread(void *arg){
    arrs *ptr;
    ptr = (arrs*)arg;
    int i = 0;
    int n = ptr->n;
    int i_1=0;
    int i_2=0;
    double *one = ptr->half_1;
    double *two = ptr->half_2;
    for (i=0; i<n; i++){
        if (i_1 < n && one[i_1] < two[i_2]){
            sorted[i] = one[i_1];
            i_1 += 1;
        }
        else{
            sorted[i] = two[i_2];
            i_2 +=1;
        }
    }
    pthread_exit(NULL);
}


int main(int argc, char *argv[])
{
    if (argc != 2){
        fprintf(stderr, "Exactly 2 parameters are required. Try again.\n");
    }
    int n = atoi(argv[1]);
    int i = 0;
    pthread_t threads[3];
    clock_t start, end;
    unsorted = (double*)malloc(n*sizeof(double));
    sorted = (double*)malloc(n*sizeof(double));
    unsorted_copy = (double*)malloc(n*sizeof(double));
    if (unsorted == NULL || sorted == NULL || unsorted_copy == NULL){
        fprintf(stderr, "Error in memory allocation.\n");
        free(unsorted);
        free(unsorted_copy);
        free(sorted);
        exit(1);
    }
    double unsorted_half1[n/2];
    double unsorted_half2[n/2];
    for(i=0; i<n; i++){
        unsorted[i] = (1 + (rand() / (RAND_MAX/99.0)));
        unsorted_copy[i] = unsorted[i];
        if ( i>=0 && i<n/2){
            unsorted_half1[i] = unsorted[i];
        }
        else if (i >= n/2){
            unsorted_half2[i-(n/2)] = unsorted[i];
        }
    }
    doubleArray sd[2];
    sd[0].size = n/2;
    sd[0].array = unsorted_half1;
    sd[1].size = n/2;
    sd[1].array = unsorted_half2;

    start = clock();
    pthread_create(&threads[0], NULL, sortThread, (void *)&sd[0]);  //sort 1st half of array
    pthread_create(&threads[1], NULL, sortThread, (void *)&sd[1]);  // sort 2nd half of array

    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);

    arrs merge;
    merge.n = n;
    merge.half_1 = sd[0].array;
    merge.half_2 = sd[1].array;

    pthread_create(&threads[2], NULL, mergeThread, (void *)&sd[1]);  // sort 2nd half of array
    pthread_join(threads[2], NULL);

    end = clock();

    printf("Sorting is done in %.1fms when two threads are used.\n", (double)(end-start));

    //....
    
    sd[0].size=n;
    sd[0].array = unsorted_copy;
    start = clock();
    pthread_create(&threads[0], NULL, sortThread, (void *)&merge);   //single-threaded sort
    pthread_join(threads[0], NULL);
    end = clock();
    printf("Sorting is done in %.1fms when one thread is used.\n", (double)(end-start));

    free(unsorted);
    free(sorted);
    free(unsorted_copy);
}

