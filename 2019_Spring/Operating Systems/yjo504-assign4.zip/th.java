
import java.lang.Runnable;
import java.util.Random;

public class th {
	public static void main(String[] args){
	    double[] unsorted;
		//double[] sorted;
		int n = Integer.parseInt(args[0]);
		int size = 0;
		if (n%2==1){ //if odd
			size = n/2+1;
		}
		else{
			size = n/2;
		}
		unsorted = new double[n];
		//sorted = new double[n];
		double[] unsorted_copy = new double[n];
		double[] half_1 = new double[n/2]; 
		double[] half_2 = new double[size];
		
		//populate unsorted with random values
		Random r = new Random();
		for(int i=0; i<n; i++){
	          unsorted[i] = (1 + 99*r.nextDouble());
	          unsorted_copy[i] = unsorted[i];
	          if ( i>=0 && i<n/2){
	              half_1[i] = unsorted[i];
	          }
	          else if (i >= n/2){
	              half_2[i-(n/2)] = unsorted[i];
	          }
	  			
		}
	
		long start = System.nanoTime();
		try {
			Thread sortA = new Thread(new SortThread(half_1));
			//NEED TO TEST IF THREAD WILL MODIFY ARRAY VALS OR NOT
			sortA.run();
			Thread sortB = new Thread(new SortThread(half_2));
			sortB.run();
			sortA.join();
			sortB.join();
			Thread merge = new Thread(new MergeThread(half_1, half_2, n));
			merge.run();
			merge.join();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		long end = System.nanoTime();
		System.out.println("Sorting is done in " + ((end - start) / 1000000 + "ms when two threads are used"));
	
		start = System.nanoTime();
		try {
			Thread sortC = new Thread(new SortThread(unsorted_copy));
			sortC.run();
			sortC.join();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		end = System.nanoTime();
		System.out.println("Sorting is done in " + ((end - start) / 1000000 + "ms when one thread is used"));
	
	}
}

class SortThread implements Runnable{
	
	private double[] array;
	public SortThread(double[] arr){
		this.array=arr;
	}
	public void run(){
		bubbleSort(array);
	}
	public void bubbleSort(double[] arr){
		int n = arr.length; 
		double temp = 0;
		for (int i = 0; i < n-1; i++) 
            for (int j = 0; j < n-i-1; j++) 
                if (arr[j] > arr[j+1]) 
                { 
                    temp = arr[j]; 
                    arr[j] = arr[j+1]; 
                    arr[j+1] = temp; 
                }
	}
}
class MergeThread implements Runnable{
	
	private double[] one;
	private double[] two;
	private double[] sorted;

	public MergeThread(double[] arr1, double[] arr2, int n){
		this.one=arr1;
		this.two=arr2;
		sorted = new double[n];
	}

	public void run(){
		int i_1 = 0;
		int i_2 = 0;
		int i = 0;
		int n = sorted.length;
		try {
			for (i=0; i<n; i++){
				if (i_2 >= n/2 || (i_1 < n/2 && one[i_1] < two[i_2])){
			        sorted[i] = one[i_1];
			        i_1 += 1;
			    }
			    else{
			        sorted[i] = two[i_2];
			        i_2 +=1;
			    }
		    }
			
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("in mergeThread... " + e);
			System.out.println("sorted size is " + sorted.length +" half1: " + one.length + " half2: "+two.length);
			System.out.println("i is " + i +" i_1: " + i_1 + " i_2: "+i_2);	
		}
	}
}
