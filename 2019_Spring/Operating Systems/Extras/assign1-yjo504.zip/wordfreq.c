#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>


#define TRUE 1
#define FALSE 0

typedef struct Node{
    char word[100];
    int count;
    struct Node *next;
}Node;

struct LL{
    Node *head;
    int wc;
};

Node* newNode(){
    Node *new;
    new = (Node*)malloc(sizeof(Node));
    if (new == NULL){
        fprintf(stderr, "error in allocating new node");
        exit(1);
    }
    return new;
}

//prints formatted list node by node
void printFromHead(Node *head){
    Node *temp;
    for(temp = head; temp != NULL; temp = temp->next){
        printf("%s appears %d times\n", temp->word, temp->count);
    }
}

//using Head node, frees linked list
void freeList(Node *head){
    Node *temp;
    Node *nodeToFree;
    for(temp = head; temp != NULL; temp = temp->next){
        if(temp != head){
            free(nodeToFree);
        }
        nodeToFree = temp;
    }
    free(nodeToFree);
}

//combines any nodes that contain the same word
Node *combineNodes(Node *head){
    Node *node;
    Node *nodeToFree;
    for (node = head; node->next!=NULL; node=node->next){
        if(strcmp(node->word, node->next->word) == 0){
            node->count += 1;
            nodeToFree = node->next;
            if (nodeToFree->next == NULL){
                node->next = NULL;
            }
            else{
                node->next = nodeToFree->next;
            }
            free(nodeToFree);
        }
    }
    return head;

}

// uses bubblesort to sort the words alphabetically, then calls combine function and returns new head of list
Node* sortInPlace(Node *head){
    char temp[100];
    int temp2;
    int swapped = TRUE;
    Node *node;
    Node *lnode = NULL;

    if(head != NULL){
        while(swapped == TRUE){
            swapped = FALSE;
            node = head;
            while(node->next != lnode){
                if (strcasecmp(node->word, node->next->word) > 0){
                    temp2 = node->count;
                    strcpy(temp, node->word);
                    node->count = node->next->count;
                    strcpy(node->word, node->next->word);
                    node->next->count = temp2;
                    strcpy(node->next->word, temp);
                    
                    swapped = TRUE;
                }
                node = node->next;
            }
            lnode = node;
        }
    }
    head = combineNodes(head);
    return head;
}

//parses file character by character, denoting end of word at whitespace
void countWords(FILE *infile, struct LL *list){
    size_t count=0, index=0;
    char temp;
    Node *head=NULL, *tail;
    Node *curr;    

    curr = newNode();
    curr->word[0] = '\0';
    curr->count = 1;
    while(1){
        temp = getc(infile);
        if (temp == EOF){
            if(curr->word[0] == '\0'){
                free(curr);
            }
            else{
                curr->word[index] = '\0';
                count++;
                if(head != NULL){
                    tail->next = curr;
                    curr = tail;
                }
            }
            tail->next = NULL;
            break;
        }
        else if (temp == ' ' || temp == '\t' || temp == '\n'){
            curr->word[index] = '\0';
            index=0;
            count++;
            if (head != NULL){
                tail->next = curr;
                tail = curr;
            }
            else{
                head = curr;
                tail = curr;
            }
            curr = newNode();
            curr->word[0] = '\0';
            curr->count = 1;
        }
        else{
            curr->word[index++] = temp;
        }
    }
    head = sortInPlace(head);
    list->head = head;
    list->wc = count;
}

int main(int argc, char *argv[]){
    
    pid_t childPid, wpid;
    int i, numWords, status=0;
    FILE *input;
    char *fileName;
    
    for(i=1; i < argc; i++){
        if (childPid = fork() == 0){
            struct LL list;
            list.head = NULL;
            list.wc = 0;
            fileName = argv[i];
            if (access(fileName,F_OK) != -1){
                input = fopen(fileName, "r");
                countWords(input, &list);
                numWords = list.wc;
                fclose(input);
                printf("Child process for %s: number of words is %d\n", fileName, numWords);
                printFromHead(list.head);
                freeList(list.head);
            }
            else{
                printf("The file named %s does not exist!\n", fileName);
            }
            exit(0);
        }

    }


    while ((wpid = wait(&status)) > 0);

    if (wpid != 0){
        printf("All %d files have been counted!\n", argc-1);
    }

}
