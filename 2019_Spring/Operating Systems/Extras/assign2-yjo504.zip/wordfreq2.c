#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define TRUE 1
#define FALSE 0

typedef struct Node{
    char word[100];
    int count;
    struct Node *next;
}Node;

struct linked_List{
    Node *head;
    int wc;
};

typedef struct thread_info{
    struct linked_List *LL;
    FILE *infile;
    char filename[50];
}TI;


Node* newNode(){
    Node *new;
    new = (Node*)malloc(sizeof(Node));
    if (new == NULL){
        perror("error in allocating new node\n");
        exit(1);
    }
    return new;
}

struct linked_List* newList(){
    struct linked_List *new;
    new = (struct linked_List*)malloc(sizeof(struct linked_List));
    if (new == NULL){
        perror("error in allocating new list\n");
        exit(1);
    }
    return new;

}

//prints formatted list node by node
void printFromHead(Node *head){
    Node *temp;
    for(temp = head; temp != NULL; temp = temp->next){
        printf("\t%s appears %d times\n", temp->word, temp->count);
    }
    printf("\n");
}

//using Head node, frees linked list
void freeList(Node *head){
    Node *temp;
    Node *nodeToFree;
    for(temp = head; temp != NULL; temp = temp->next){
        if(temp != head){
            free(nodeToFree);
        }
        nodeToFree = temp;
    }
    free(nodeToFree);
}

//combines any nodes that contain the same word
Node *combineNodes(Node *head){
    Node *node;
    Node *nodeToFree;
    for (node = head; node->next!=NULL; node=node->next){
        if(strcmp(node->word, node->next->word) == 0){
            node->count += 1;
            nodeToFree = node->next;
            if (nodeToFree->next == NULL){
                node->next = NULL;
            }
            else{
                node->next = nodeToFree->next;
            }
            free(nodeToFree);
        }
    }
    return head;

}


//assumes both are sorted
struct linked_List* combineLLs(struct linked_List *one, struct linked_List *two){
    Node *n1 = one->head;
    Node *n2 = two->head;
    //if neither list exists
    if (n1 == NULL && n2==NULL){
        return NULL;
    }
    Node *tail;
    Node *temp;
    struct linked_List* new;
    new = newList();
    new->head = NULL;
    new->wc = 0;
    if (n1 != NULL && n2 != NULL){
        while( n1 != NULL && n2 != NULL){
            temp = newNode();
            if(strcmp(n1->word, n2->word) == 0){
                strcpy(temp->word, n1->word);
                temp->count = n1->count + n2->count;
                temp->next = NULL;
                if(new->head == NULL){
                    new->head = temp;
                    tail = temp;
                }
                else{
                    tail->next = temp;
                    tail = temp;
                }
                n1 = n1->next;
                n2 = n2->next;
            }
            //if n1 is alphabetically higher than n2
            else if (strcmp(n1->word, n2->word) < 0){
                strcpy(temp->word, n1->word);
                temp->count = n1->count;
                temp->next = NULL;
                if(new->head == NULL){
                    new->head = temp;
                    tail = temp;
                }
                else{
                    tail->next = temp;
                    tail = temp;
                }
                n1 = n1->next;
            }
            else{
                strcpy(temp->word, n2->word);
                temp->count = n2->count;
                temp->next = NULL;
                if(new->head == NULL){
                    new->head = n2;
                    tail = n2;
                }
                else{
                    tail->next = n2;
                    tail = n2;
                }
                n2 = n2->next;
            }
            new->wc += tail->count;
        }
    }
    
    else if (n1 != NULL && new->head == NULL){
        temp = newNode();
        strcpy(temp->word, n1->word);
        temp->count = n1->count;
        temp->next = NULL;
        
        new->head = temp;
        tail = temp;
        new->wc += tail->count;
        n1=n1->next;
    }
    
    
    else if (n2 != NULL && new->head == NULL){
        temp = newNode();
        strcpy(temp->word, n2->word);
        temp->count = n2->count;
        temp->next = NULL;

        new->head = temp;
        tail = temp;
        new->wc += tail->count;
        n2 = n2->next;
    }
    while (n1 != NULL){
        temp = newNode();
        strcpy(temp->word, n1->word);
        temp->count = n1->count;
        temp->next = NULL;

        tail->next = temp;
        tail = temp;
        new->wc += tail->count;
        n1 = n1->next;
    }

    while (n2 != NULL){
        temp = newNode();
        strcpy(temp->word, n2->word);
        temp->count = n2->count;
        temp->next = NULL;

        tail->next = temp;
        tail = temp;
        new->wc += tail->count;
        n2 = n2->next;
    }

    return new;

}

// uses bubblesort to sort the words alphabetically, then calls combine function and returns new head of list
Node* sortInPlace(Node *head){
    char temp[100];
    int temp2;
    int swapped = TRUE;
    Node *node;
    Node *lnode = NULL;

    if(head != NULL){
        while(swapped == TRUE){
            swapped = FALSE;
            node = head;
            while(node->next != lnode){
                if (strcasecmp(node->word, node->next->word) > 0){
                    temp2 = node->count;
                    strcpy(temp, node->word);
                    node->count = node->next->count;
                    strcpy(node->word, node->next->word);
                    node->next->count = temp2;
                    strcpy(node->next->word, temp);
                    
                    swapped = TRUE;
                }
                node = node->next;
            }
            lnode = node;
        }
    }
    head = combineNodes(head);
    return head;
}

//parses file character by character, denoting end of word at whitespace
void *countFileThread(void *arg){
    TI *info;
    info = (TI*)arg;
    FILE *infile = info->infile;
    struct linked_List *list = info->LL;
    char *fileName = info->filename;

    size_t count=0, index=0, unq=0;
    char temp;
    Node *head=NULL, *tail;
    Node *curr;    

    curr = newNode();
    curr->word[0] = '\0';
    curr->count = 1;
    while(1){
        temp = getc(infile);
        if (temp == EOF){
            if(curr->word[0] == '\0'){
                free(curr);
            }
            else{
                curr->word[index] = '\0';
                count++;
                if(head != NULL){
                    tail->next = curr;
                    curr = tail;
                }
            }
            tail->next = NULL;
            break;
        }
        else if (temp == ' ' || temp == '\t' || temp == '\n'){
            curr->word[index] = '\0';
            index=0;
            count++;
            if (head != NULL){
                tail->next = curr;
                tail = curr;
            }
            else{
                head = curr;
                tail = curr;
            }
            curr = newNode();
            curr->word[0] = '\0';
            curr->count = 1;
        }
        else{
            curr->word[index++] = temp;
        }
    }
    head = sortInPlace(head);
    list->head = head;
    list->wc = count;
    for(head; head!=NULL; head = head->next){
        unq++;
    }
    printf(" number of total words in file %s is %zu, number of unique words is %zu\n",
            fileName, count, unq);
    printFromHead(list->head);

    pthread_exit((void*)list);
}

int main(int argc, char *argv[]){
    
    sem_t sem;
    pthread_t tid;
    int i;
    FILE *input;
    char *fileName;
    Node *trav;
    struct linked_List *temp;
    struct linked_List *master;
    struct linked_List *prevMaster;
    TI *info;
    size_t unq = 0;

    //2nd argument means shared by any process, 3rd means initial value of semaphore
    if (sem_init(&sem, 0, 1) == -1){
        perror("Issue initializing semaphore in main method");
        exit(1);
    }

    master = (struct linked_List*) malloc(sizeof(struct linked_List));
    master->head = NULL;
    master->wc = 0;

    for(i=0; i < argc-1; i++){
        sem_wait(&sem);
        fileName = argv[i+1];
        if (access(fileName,F_OK) != -1){
            input = fopen(fileName, "r");
        }
        else{
            printf("The file named %s does not exist!\n", fileName);
            continue;
        }
        temp = (struct linked_List*)malloc(sizeof(struct linked_List));
        if (temp == NULL){
            perror("Issue allocating memory for linked_List in main method");
            exit(1);
        }
        info = (TI*)malloc(sizeof(TI));
        if (info == NULL){
            perror("Issue allocating memory for thread_info in main method");
            free(temp);
            exit(1);
        }
        temp->head = NULL;
        temp->wc = 0;
        info->LL = temp;
        info->infile = input;
        strcpy(info->filename, fileName);

        printf("Thread %d:", i+1);
        pthread_create(&tid, NULL, countFileThread, (void*)info);
        pthread_join(tid, (void**)&temp);
        fclose(input);
        temp->head = sortInPlace(temp->head);
        //if master not set up yet, first file will be master.
        if (master->head == NULL){
            master = temp;
        }
        //combineLists frees both old lists & creates a new one.
        else{
            prevMaster = master;
            master = combineLLs(prevMaster, temp);
            if (master == NULL){
                free(info);
                sem_post(&sem);
                continue;
            }
        }
        free(info);
        sem_post(&sem);
    }
    for(trav=master->head; trav !=NULL; trav = trav->next){
        unq++;
    }

    printf("All %d files have been counted and a total of %d words found, with %zu unique words!\n", argc-1, master->wc, unq);
    printFromHead(master->head);
    freeList(master->head);
    free(master);
    return(0);
}
