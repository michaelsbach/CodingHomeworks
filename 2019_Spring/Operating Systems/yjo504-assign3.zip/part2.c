#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>

#define NUMFRAMES 8
#define TABLESIZE 32
#define DBITS 7
#define PBITS 5
#define FBITS 3

int CLK = 0;

typedef struct Pagetable{
    int vi;  //valid if =1, invalid if =0
    int fnum;  //index of frame num
}PGTB;

int find_a_freeFrame(int *freeFrames){
    int i;
    //freeFrames[0] will never be == 0, (due to OS reservation), so starts at i=1
    for (i=1; i< NUMFRAMES; i++){
        if (freeFrames[i] == 0){
            return i;
        }
    }
    return -1;
}

//returns index of the least recently used frame so it can be replaced
int find_LRU(int *frameTime){
    int min = INT_MAX;
    int LRUindex;
    int i;
    //starting for loop at i=1 since OS' index 0 should not be replaced
    for (i=1; i<NUMFRAMES; i++){
        if (frameTime[i] < min){
            min = frameTime[i];
            LRUindex = i;
        }
    }
    return LRUindex;
}

//translates logical address to physical address 
// AND sets time of frame allocation through frameTime array
int getPA(PGTB *PT, int (*ptrFrameTime)[NUMFRAMES], int pnum, int offset){
    unsigned long fnum;
    fnum = PT[pnum].fnum;
    (*ptrFrameTime)[fnum] = CLK;     //assigns time of write, used in find_LRU
    return ((fnum << 7) + offset);
}
  
    
int main(int argc, char *argv[]){

    int revMap[NUMFRAMES] = {0};
    int frameTime[NUMFRAMES] = {0};
    int freeFrames[NUMFRAMES] = {1,0};
    PGTB PT[TABLESIZE];
    FILE *infile;
    FILE *outfile;
    char *infileName;
    char *outfileName;
 
    int i;
    int frameindex;
    int replaceindex;
    unsigned long pnum;
    unsigned long offset;
    unsigned long LA;
    unsigned long PA;
    int readBytes;
    int pagefault = 0;

    if (argc != 3){
           fprintf(stderr, "Only 2 parameters are allowed. Try again.\n");
    }
    for (i=0; i< TABLESIZE; i++){
        PT[i].vi = 0;
    }
    infileName = argv[1];
    outfileName = argv[2];
    if (access(infileName,F_OK) != -1){
        infile = fopen(infileName, "rb");
        outfile = fopen(outfileName, "wb");
        while ( 1 ) {
            readBytes = fread(&LA, sizeof(LA), 1, infile);
            if (readBytes == 0){
                break;
            }
            CLK += 1;
            pnum = LA >> DBITS;
            offset = LA & 0x07F;
            if (PT[pnum].vi == 0){
                pagefault += 1;
                frameindex = find_a_freeFrame(freeFrames);
                if ( frameindex >= 0 ){
                    freeFrames[frameindex] = 1;
                    PT[pnum].fnum = frameindex;
                    revMap[frameindex] = pnum;
                }
                else{ //no free frames, need to replace LRU frame
                    replaceindex = find_LRU(frameTime);
                    PT[revMap[replaceindex]].vi = 0;
                    PT[pnum].fnum = replaceindex;
                    revMap[replaceindex] = pnum; 
                }
                PT[pnum].vi = 1;
            }
            //physical address obtainment & writing happens always,
            //irregardless if PT[pnum] is invalid or valid
            PA = getPA(PT, &frameTime, pnum, offset);
            fwrite(&PA, sizeof(PA), 1, outfile); 
        }

    }
    printf("Number of pagefaults is %d\n", pagefault);
    fclose(infile);
    fclose(outfile);
}

