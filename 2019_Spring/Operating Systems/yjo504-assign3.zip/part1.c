#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
   
#define DBITS 7
#define PBITS 5
#define FBITS 3

int main(int argc, char *argv[]){
    unsigned long intemp;
    unsigned long pagenum;
    unsigned long framenum;
    unsigned long d_num;
    int PT[10] = {2, 4, 1, 7, 3, 5, 6};
    int PF[8];
    FILE *infile;
    FILE *outfile;
    char *infileName;
    char *outfileName;
    int readBytes;
    int writeBytes;

    if (argc != 3){
        fprintf(stderr, "Only 2 parameters are allowed. Try again.\n");
    }
    infileName = argv[1];
    outfileName = argv[2];
    if (access(infileName,F_OK) != -1){
        infile = fopen(infileName, "rb");
        outfile = fopen(outfileName, "wb");
        while ( 1 ) {
            readBytes = fread(&intemp, sizeof(intemp), 1, infile);
            if (readBytes == 0){
                break;
            }
            pagenum = intemp >> DBITS;
            d_num = intemp & 0x07F;
            framenum = PT[pagenum];
            printf("LA: %lu ", intemp);
            intemp = (framenum << 7) + d_num;
            printf("PA: %lu \n", intemp);
            writeBytes = fwrite(&intemp, sizeof(intemp), 1, outfile);
        }
    }
    fclose(infile);
    fclose(outfile);

}
