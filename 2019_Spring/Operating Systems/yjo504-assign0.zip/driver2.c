//author : Michael Schwarzbach (yjo504)
//class  : CS 3733 (Operating Systems)

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "myio.h"


//read each line of input, remove extra spaces, and output lines into output.txt

int main(int argc, char *argv[]){

    if (argc != 3 ){
        fprintf(stderr, "Incorrect # of command line arguments. Format should be: driver2 input.txt output.txt \n");
        exit(1);
    }
    char *input_NoSpaces;
    FILE *infile, *outfile;

    infile = fopen(argv[1], "r");
    input_NoSpaces = EraseExtraSpaces(infile);
    fclose(infile);
    
    outfile = fopen(argv[2], "w");
    fprintf(outfile, "%s", input_NoSpaces);
    fclose(outfile);
    
    free(input_NoSpaces);
    return(EXIT_SUCCESS);

}
