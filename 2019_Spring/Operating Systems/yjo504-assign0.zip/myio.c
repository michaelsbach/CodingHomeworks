/*
 * File: myio.c
 * Author: Michael Schwarzbach
 * Version: 1.0
 */

#include<stdlib.h>
#include<stdio.h>
#include"myio.h"

/*
 * Function: ReadInteger
 * Usage: i = ReadInteger();
 * ------------------------
 * ReadInteger reads a line of text from standard input and scans
 * it as an integer.  The integer value is returned.  If an
 * integer cannot be scanned or if more characters follow the
 * number, the user is given a chance to retry.
 */
int ReadInteger(void){
    char *strTemp = ReadLineFile(stdin);
    long int temp = atol(strTemp);
    while (temp == 0){
        printf("Please enter a non-zero integer.\n");
        strTemp = ReadLineFile(stdin);
        temp = atof(strTemp);
    }
    free(strTemp);
    return temp;
}

/*
 * Function: ReadDouble
 * Usage: x = ReadDouble();
 * ---------------------
 * ReadDouble reads a line of text from standard input and scans
 * it as a double.  If the number cannot be scanned or if extra
 * characters follow after the number ends, the user is given
 * a chance to reenter the value.
 */
double ReadDouble(void){
    char *strTemp = ReadLineFile(stdin);
    double temp = atof(strTemp);
    while (temp == 0.0){
        printf("Please enter a non-zero double.\n");
        strTemp = ReadLineFile(stdin);
        temp = atof(strTemp);
    }
    free(strTemp);
    return temp;

}

/* 
 * Function: ReadLine
 * Usage: s = ReadLine();
 * ---------------------
 * ReadLine reads a line of text from standard input and returns
 * the line as a string.  The newline character that terminates
 * the input is not stored as part of the string.
 */
char *ReadLine(void){
    return(ReadLineFile(stdin));
}

/* 
 * Function: ReadLine
 * Usage: s = ReadLine(infile);
 * ----------------------------
 * ReadLineFile reads a line of text from the input file which 
 * is already open and pointed by infile. It then reads the line, 
 * dynamically allocates space, and returns the line as a string. 
 * The newline character that terminates the input is not stored 
 * as part of the * string.  
 * The ReadLine function returns NULL if infile is at the 
 * end-of-file position. 
 * Note: the above ReadLine(); can simply be implemented as 
 *  { return(ReadLineFile(stdin)); } */


//DO NOT NEED TO FREE HERE. Use free(string) within Driver program
char *ReadLineFile(FILE *infile){

    size_t size = 1, index=0;
    char *string = NULL, *strTemp = NULL;
    char temp;
    string = (char*)malloc(sizeof(char));
    if (string == NULL){
        free(string);
        fprintf(stderr, "malloc error. Look at program.");
        return NULL;
    }
    while(1){
        temp = getc(infile);
        if (temp == '\n')
            break;
        if (temp == EOF){
            free(string);
            return NULL;
        }
        size++;
        strTemp = realloc(string, (size)*sizeof(char));
        if (strTemp == NULL){
            free(string);
            fprintf(stderr, "realloc error. Look at program.");
            return NULL;
        }
        string = strTemp;
        string[index++] = temp;
    }
    string[index] = '\0';
    return string;
}

char *EraseExtraSpaces(FILE *infile){

    size_t size = 100, index=0;
    char *string = NULL, *strTemp = NULL;
    char temp = '\0', prev;
    string = (char*)malloc(size*sizeof(char));
    if (string == NULL){
        free(string);
        fprintf(stderr, "malloc error. Look at program.");
        return NULL;
    }
    while(1){
        if (temp != '\0'){
            prev = temp;
        }
        temp = getc(infile);
        if (temp == EOF)
            break;
        if (temp == ' ' && prev == ' ')
            continue;
        if (index >= size){
            size += 20;
            strTemp = realloc(string, (size)*sizeof(char));
            if (strTemp == NULL){
                free(string);
                fprintf(stderr, "realloc error. Look at program.");
                return NULL;
            }
            string = strTemp;
        }
        string[index++] = temp;
    }
    string[index] = '\0';
    return string;
}


