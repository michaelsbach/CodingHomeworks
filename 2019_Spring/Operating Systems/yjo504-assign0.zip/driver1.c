//author : Michael Schwarzbach (yjo504)
//class  : CS 3733 (Operating Systems)


//get 3 cmd-line args: x,y,z. Then asks user to enter X ints, Y doubles, and Z lines. 
//After every data entry, the program prints back the entered data to stdout while printing errors to stderr
//Also, keep track of largest int, double, and string. At the end, print these biggest values.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "myio.h"

int main(int argc, char *argv[]){

    if (argc != 4){
        fprintf(stderr, "Incorrect # of command line arguments. Format should be: driver1 x y z (where x, y, and z are integers)\n");
        exit(1);
    }

    double tempDouble, maxDouble=0;
    int i, tempInt, maxInt=0, strSize, x, y, z;
    char *tempStr = NULL;
    char *maxStr = NULL;

    x = strtol(argv[1], NULL, 10);
    y = strtol(argv[2], NULL, 10);
    z = strtol(argv[3], NULL, 10);
    
    if (x > 0){
        printf("Enter %d integers.\n", x);
        for (i=0; i<x; i++){
            tempInt = ReadInteger();
            printf("You entered \'%d\'\n", tempInt);
            if (tempInt > maxInt)
                maxInt = tempInt;
        }
    }
    if (y > 0){
        printf("Enter %d doubles.\n", y);
        for (i=0; i<y; i++){
            tempDouble = ReadDouble();
            printf("You entered \'%.3f\'\n", tempDouble);
            if (tempDouble > maxDouble)
                maxDouble = tempDouble;
        }
    }


    if (z > 0){
        printf("Enter %d lines.\n", z);
        for (i=0; i<z; i++){
            tempStr = ReadLine();
            printf("You entered \'%s\'\n", tempStr);
            strSize = strlen(tempStr)+1;
            if ( maxStr == NULL ){
                maxStr = (char*) malloc(strSize*sizeof(char));
                if (maxStr == NULL){
                    fprintf(stderr, "error in malloc\n");
                    free(tempStr);
                    exit(1);
                }
                strcpy(maxStr, tempStr);
            }
            else if (strSize > strlen(maxStr)){
                free(maxStr);
                maxStr = (char*) malloc(strSize*sizeof(char));
                if (maxStr == NULL){
                    fprintf(stderr, "error in malloc\n");
                    free(tempStr);
                    exit(1);
                }
                strcpy(maxStr, tempStr);
            }
            free(tempStr);
        }
    }
    printf("Largest int is %d\nLargest double is %.3f\nLargest string is \'%s\'\n", maxInt, maxDouble, maxStr);
    free(maxStr);
    return(EXIT_SUCCESS);
}

